@extends('layouts.main')

@section('titulo','Criar ItensEntrada)

@section('conteudo')
  
@endsection('conteudo')