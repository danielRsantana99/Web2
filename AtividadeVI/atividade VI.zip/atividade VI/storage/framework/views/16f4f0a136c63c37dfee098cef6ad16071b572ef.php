<?php $__env->startSection('titulo','Clientes'); ?>

<?php $__env->startSection('conteudo'); ?>
	<table class="table">
	  <thead>
	    <tr>
	      <th scope="col">NOME</th>
	      <th scope="col">DEBITO</th>
	      <th scope="col">DESCRIÇÃO</th>
	      <th scope="col">OPÇÕES</th>
	    </tr>
	  </thead>
	  <tbody>
	    <tr>
	      <td>Jose bento</td>
	      <td>203.00</td>
	      <td>rua alta</td>
	      <td>
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<a href="" class="btn btn-primary" >editar cliente</a>
	      		</div>
	      	<div class="col-sm-6">
	      		<form action="" method="POST">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
				
				<input type="submit" class="btn btn-danger" value="DELETAR">
				</form>
	      	</div>
	      	</div>
	      </td>
	    </tr>
	    <tr>
	      <td>ana vitoria</td>
	      <td>123.00</td>
	      <td>avenida alto</td>
	      <td>
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<a href="" class="btn btn-primary" >editar cliente</a>
	      		</div>
	      	<div class="col-sm-6">
	      		<form action="" method="POST">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
				
				<input type="submit" class="btn btn-danger" value="DELETAR">
				</form>
	      	</div>
	      	</div>
	      </td>
	    </tr>
	    <tr>
	      <td>marcos</td>
	      <td>24.00</td>
	      <td></td>
	      <td>
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<a href="" class="btn btn-primary" >editar cliente</a>
	      		</div>
	      	<div class="col-sm-6">
	      		<form action="" method="POST">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
				
				<input type="submit" class="btn btn-danger" value="DELETAR">
				</form>
	      	</div>
	      	</div>
	      </td>
	    </tr>
	    <tr>
	      <td>daniel </td>
	      <td>2000</td>
	      <td>rua rabin</td>
	      <td>
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<a href="" class="btn btn-primary" >editar cliente</a>
	      		</div>
	      	<div class="col-sm-6">
	      		<form action="" method="POST">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
				
				<input type="submit" class="btn btn-danger" value="DELETAR">
				</form>
	      	</div>
	      	</div>
	      </td>
	    </tr>
	    <tr>
	      <td>Arivan</td>
	      <td>403.21</td>
	      <td>rua alta</td>
	     <td>
	      	<div class="row">
	      		<div class="col-sm-6">
	      			<a href="" class="btn btn-primary" >editar cliente</a>
	      		</div>
	      	<div class="col-sm-6">
	      		<form action="" method="POST">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
				
				<input type="submit" class="btn btn-danger" value="DELETAR">
				</form>
	      	</div>
	      	</div>
	      </td>
	    </tr>
	  </tbody>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documentos/projetos/projetoLaravel3/resources/views/clientes/index.blade.php ENDPATH**/ ?>