<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-with, initial-scale=1.0">
    <title>aluno</title>
</head>
<body>
    <h1>pagina de aluno</h1>
    
    <p>parametros opcional <?php echo e($id); ?></p>
</body>
</html>
<?php /**PATH /home/daniel/Documentos/projetos/projetoLaravel3/resources/views/aluno.blade.php ENDPATH**/ ?>