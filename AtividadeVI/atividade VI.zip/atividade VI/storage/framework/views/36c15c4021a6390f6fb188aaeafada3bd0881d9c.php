<?php $__env->startSection('titulo','Criar Fornecedor'); ?>

<?php $__env->startSection('conteudo'); ?>
 
    <form class="contact_form" action="<?php echo e(route('fornecedores.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-sm-6 mb-6">
                <div class="form-group">
                    <label class="h6 small d-block text-uppercase">
                        NOME FORNECEDOR
                        <span class="text-danger">*</span>
                    </label>

                    <div class="input-group">
                        <input class="form-control" type="text" name="nome" id="nome" required="" placeholder="">
                    </div>
                </div>
            </div>
            <div class="col-sm-6 mb-6">
                <div class="form-group">
                    <label class="h6 small d-block text-uppercase">
                        CNPJ
                        <span class="text-danger">*</span>
                    </label>

                    <div class="input-group">
                        <input class="form-control" type="text" name="cnpj" id="cnpj" required="" placeholder="">
                    </div>
                </div>
            </div>
            <div class="col-sm-6 mb-6">
                <div class="form-group">
                    <label class="h6 small d-block text-uppercase">
                        ENDEREÇO
                        <span class="text-danger">*</span>
                    </label>

                    <div class="input-group">
                        <input class="form-control" type="text" name="endereco" id="endereco" required="" placeholder="">
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="row">
            <input name="submit" type="submit" class="btn btn-block btn-primary" value="CADASTRAR">
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/daniel/Documentos/projetos/projetoLaravel3/resources/views/fornecedores/create.blade.php ENDPATH**/ ?>